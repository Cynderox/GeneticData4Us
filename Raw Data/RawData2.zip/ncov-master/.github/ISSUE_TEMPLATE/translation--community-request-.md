---
name: Translation (community request)
about: Request translation of the situation report to another language
title: "[Language translation request]"
labels: ''
assignees: cassiawag

---

**What language would you like the situation reports to be translated into?**  


**Are you available to help translate?** (Either way is alright, just let us know! :)
