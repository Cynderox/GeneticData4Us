---
name: Feature request
about: Want us to add a feature to Nextstrain?
title: "[Feature request]"
labels: enhancement
assignees: ''

---

**Context**  
How would this feature help you? What would it enable you to do?  

**Description**   
A clear and concise description of what you want to happen  

**Examples**  

**Possible solution**   
(Optional)
