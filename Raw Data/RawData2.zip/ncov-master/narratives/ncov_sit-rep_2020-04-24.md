---
title: Genomic analysis of COVID-19 spread. Situation report 2020-04-24.
authors:
  - Cassia Wagner
  - Sidney M. Bell
  - Emma Hodcroft
  - Nicola Müller
  - James Hadfield
  - Misja Ilcisin
  - Richard Neher
  - Trevor Bedford
authorLinks:
  - https://bedford.io/team/cassia-wagner/
  - https://twitter.com/sidneymbell
  - https://neherlab.org/emma-hodcroft.html
  - https://bedford.io/team/nicola-mueller/
  - https://bedford.io/team/james-hadfield/
  - https://bedford.io/team/misja-ilcisin/
  - https://neherlab.org/richard-neher.html
  - https://bedford.io/team/trevor-bedford/
affiliations: "Fred Hutch, Seattle, USA; Biozentrum, Basel, Switzerland; CZI, CA, USA"
translators:
translatorLinks:
license: "CC-BY"  
licenseLink: "https://creativecommons.org/licenses/by/4.0/"
dataset: "https://nextstrain.org/ncov/africa/2020-04-24?f_region=Africa&d=map,tree"

abstract: "This weekly report uses publicly shared genomic data to track the spread of COVID-19. This week, we focus on Africa. We report many separate introductions to the Democratic Republic of the Congo, Senegal, Ghana, Nigeria, Gambia, Algeria, and South Africa. We find evidence of local transmission in Kinshasa, DRC; Dakar and Touba, Senegal; and Greater Accra, Ghana."
---
<!-- Translators: Only text after : in the above ^ needs to be translated -->
<!-- Comment tags like these do not need to be translated, they are only to help you! -->
<!-- Ensure that links always end in a 'letter' (. counts) If some kind of text doesn't follow them, it breaks the slide. -->
<!-- numbers can be tagged ilke this: 161</tag> - this is just for us to help find them to update! Just leave in the </tag> bit. -->

<!-- This is left-side text 1-->
# [Table of Contents](https://nextstrain.org/ncov/africa/2020-04-24?d=map,tree&f_region=Africa)

* [Background resources](https://nextstrain.org/narratives/ncov/sit-rep/2020-04-24?n=2).     
* [About this data](https://nextstrain.org/narratives/ncov/sit-rep/2020-04-24?n=3).
* [The genetic diversity of SARS-CoV-2 in Africa](https://nextstrain.org/narratives/ncov/sit-rep/2020-04-24?n=4).
* [Updates for the DRC](https://nextstrain.org/narratives/ncov/sit-rep/2020-04-24?n=5).
* [Updates for Senegal](https://nextstrain.org/narratives/ncov/sit-rep/2020-04-24?n=7).
* [Updates for Ghana](https://nextstrain.org/narratives/ncov/sit-rep/2020-04-24?n=8).
* [Updates for Algeria, Gambia, Nigeria, and South Africa](https://nextstrain.org/narratives/ncov/sit-rep/2020-04-24?n=10).
* [What you can do](https://nextstrain.org/narratives/ncov/sit-rep/2020-04-24?n=11).
* [Scientific credit](https://nextstrain.org/narratives/ncov/sit-rep/2020-04-24?n=12).

<!-- This is right-side text -->
```auspiceMainDisplayMarkdown
# Executive summary

We analyzed 1,338 publicly shared COVID-19 genomes. By comparing these viral genomes to each other, we can characterize how COVID-19 is moving around the world and spreading locally. This week we focus on Africa and report:
<br><br>
* Many separate introductions of SARS-CoV-2 to the African continent, primarily from Europe (although sampling bias may contribute to this inference)
<br><br>
* At least 7 introductions to the DRC  
<br><br>
* 2 separate transmission chains circulating in Kinshasa, DRC  
<br><br>
* Of 8 introductions to Senegal, at least 2 seeded local transmission chains in Dakar and Touba
<br><br>
* Local transmission in Greater Accra, Ghana, after 7 introductions to this region
<br><br>
* Scattered introductions to Algeria, Gambia, Nigeria, and South Africa
```


<!-- ############ SLIDE BREAK ############# -->

<!-- This is left-side text 2-->
# [COVID-19 Resources](https://nextstrain.org/ncov/africa/2020-04-24?d=tree&p=full&legend=closed&f_region=Africa)
We've prepared some resources that will make interpreting the data we present in this narrative easier.
#### Nextstrain Resources  
* [START HERE: How to read a phylogeny](https://nextstrain.org/narratives/trees-background/).  
* [Background on coronaviruses](https://nextstrain.org/help/coronavirus/human-CoV).
* [Common misconceptions](https://nextstrain.org/narratives/ncov/sit-rep/2020-03-13?n=11).

#### External Resources  
* [Ask a Scientist & FAQs](https://covid19.fas.org/).
* [WHO Situation Reports](https://www.who.int/emergencies/diseases/novel-coronavirus-2019/situation-reports).
* [CDC Resources](https://www.cdc.gov/coronavirus/2019-ncov/index.html).
* [The NYTimes COVID-19 coverage](https://www.nytimes.com/news-event/coronavirus).
<!-- There is no right-side text -->


<!-- ############ SLIDE BREAK ############# -->

<!-- This is left-side text 3-->
# [A note on sampling](https://nextstrain.org/ncov/africa/2020-04-24?d=map&f_region=Africa&p=full)
We currently have sequences from samples taken in 6 continents. In Africa, we have samples from 7 countries. This is an incredible achievement -- sequencing an unknown, large RNA virus in the midst of a pandemic is difficult, and is only possible through the incredible work and timely sharing of data by scientists and physicians around the world.
<br><br>
While this data enables us to infer many useful characteristics of the outbreak and track its spread in real time, it's important to emphasize that our conclusions are limited by the available data.
<br><br>
For example, the map shows very few sequences from East Africa. This is NOT because COVID-19 isn't circulating in these areas, or that these cases are not as crucial to understand; rather, we just don't have much data available from these areas. The size of each circle on the map indicates how much data is currently available from that area, rather than the true size of the outbreak.

<!-- There is NO right-side text -->


<!-- ############ SLIDE BREAK ############# -->
<!-- This is left-side text 4-->
# [Many separate introductions have seeded diverse local transmission chains in Africa](https://nextstrain.org/ncov/africa/2020-04-24?d=tree,map&f_region=Africa&p=full&r=country&legend=open)
  At the time of writing, the [Africa CDC](https://africacdc.org/covid-19/) reports 26,144 confirmed COVID-19 cases and 1,247 deaths across the African Union.
  We have viral genomes from 83 of these cases from 7 African nations, shown here (in color) against a backdrop of contextual sequences from around the world (in gray). We applaud the local public health departments for their rapid response and open data sharing.
  <br><br>
  These samples span the full diversity of the tree, indicating that there have been many independent introductions to the African continent.
  Many of these introductions appear to be from Europe, although this may be skewed by the fact that we have more sequences from Europe than from most other places in the world. We can't rule out the possibility of unsampled, intermediate transmissions elsewhere.
  <br><br>
  We don't seen evidence that all of these introductions have led to community transmission, but we see clear clusters in some locations.

<!-- There is no right side text -->


<!-- ############ SLIDE BREAK ############# -->
<!-- This is left-side text 5-->
# [At least 7 introductions to the DRC](https://nextstrain.org/ncov/africa/2020-04-24?d=tree,map&f_region=Africa&p=full&r=country&legend=closed&f_country=Democratic%20Republic%20of%20the%20Congo)

There are [359 confirmed cases of COVID-19 in the DRC with 25 deaths](https://africacdc.org/covid-19/). On Nextstrain, we have 40 sequences from the DRC.
<br><br>
These sequences fall across the tree, with evidence for at least 7 separate introductions. As shown here, introductions look like a color change between a virus sample (tips of the tree) and its ancestors (the internal nodes or branch points that lead to it).
<br><br>
Here, we can see 7 places where the colors have changed from grey to orange, representing an introduction. From these 7 introductions, we see evidence for at least 2 local transmission chains.

<!-- There is no right side text -->

<!-- ############ SLIDE BREAK ############# -->
<!-- This is left-side text 6-->
# [Two local transmission chains in Kinshasa, seeded in early March](https://nextstrain.org/ncov/africa/2020-04-24?d=tree&f_country=Democratic%20Republic%20of%20the%20Congo&f_region=Africa&label=clade:A2a&p=full&legend=closed&m=div)

In this zoomed-in divergence view, we can see two clusters representing likely local transmission.
Local transmission looks like a tight cluster of cases from the same location, sampled over time, with accumulating genetic diversity (longer branch lengths, representing more mutations).
<br><br>
Toward the top of this view, we see a cluster of cases from Kinshasa, all sampled between March 9 and March 22.
<br><br>
Toward the middle, we see another cluster of cases from Kinshasa, sampled between March 15 and April 6th.
<br><br>
From this, we can conclude that at least 2 separate transmission chains were circulating in Kinshasa in between early March and early April 2020.
<br><br>
The DRC reported its first cases of COVID-19 [to the WHO](https://apps.who.int/iris/bitstream/handle/10665/331763/SITREP_COVID-19_WHOAFRO_20200415-eng.pdf) on March 10. The first sample on Nextstrain was collected on March 9, and was reported in our [Situation Report for March 27](https://nextstrain.org/narratives/ncov/sit-rep/2020-03-27?n=16).
<!-- There is no right-side text -->


<!-- ############ SLIDE BREAK ############# -->
<!-- This is left-side text 7-->
# [At least 8 introductions to Senegal, with 2 local transmission chains](https://nextstrain.org/ncov/africa/2020-04-24?d=tree,map&f_country=Senegal&f_region=Africa&m=div&p=full)

Similar to the patterns found in the DRC, here we see samples from Senegal spanning the full genetic diversity of the tree. The phylogenetic placement of these samples indicates that there were at least 8 separate introductions to Senegal between late February and late March. Senegal reported its first  COVID-19 cases to the WHO on February 28, the same day that the first viral sample was collected for sequencing.
<br><br>
As we reported in our [April 3 Situation Report](https://nextstrain.org/narratives/ncov/sit-rep/2020-04-03?n=5), at least 2 of these introductions in late February or early March have led to ongoing local transmission clusters in Dakar and Touba, respectively.
<br><br>
Although the most recent sequence on Nextstrain from Senegal is from March 20, there are [currently 215 known, active cases](http://www.sante.gouv.sn/sites/default/files/COMMUNIQUE%2053%20DU%2023%20AVRIL%202020.pdf) of COVID-19 in Senegal.

<!-- There is no right-side text -->


<!-- ############ SLIDE BREAK ############# -->
<!-- This is left-side text 8-->
# [At least 7 introductions to Ghana](https://nextstrain.org/ncov/africa/2020-04-24?d=tree,map&f_country=Ghana&f_region=Africa&p=full)

There are [1,154 confirmed cases of COVID-19 in Ghana with 9 known deaths](https://africacdc.org/covid-19/). On Nextstrain, there are 14 sequences from Ghana which are spread across the phylogenetic tree, representing at least 7 separate introductions.
<br><br>
The first case in Ghana was reported to the WHO on March 11, and the first viral genome on Nextstrain was collected on March 24.

<!-- There is no right-side text --><!-- ############ SLIDE BREAK ############# -->
<!-- This is left-side text 9-->
# [Local transmission in Greater Accra, Ghana](https://nextstrain.org/ncov/africa/2020-04-24?label=clade:B4&c=division&d=tree,map&f_country=Ghana,Senegal&f_region=Africa&p=full&r=location&legend=closed)

Here, we see a cluster of closely related cases from the Greater Accra region of Ghana, sampled between March 25 and March 30.
The common ancestor of these cases dates to mid-February or early March, and was most likely imported from Asia.
<br><br>
Interestingly, there is a sample from Senegal that groups tightly with this cluster, suggesting the possibility of a transmission between Senegal and Ghana.

<!-- There is no right-side text -->


<!-- ############ SLIDE BREAK ############# -->
<!-- This is left-side text 10-->
# [Scattered introductions to Algeria, Gambia, Nigeria, and South Africa](https://nextstrain.org/ncov/africa/2020-04-24?c=division&d=tree,map&f_country=Algeria,Gambia,Nigeria,South%20Africa&f_region=Africa&p=full&r=division)

Here, we see samples isolated from Algeria, Gambia, Nigeria and South Africa. These samples are scattered across the full tree and are largely isolated from one another.
<br><br>
This is evidence for many separate introductions, largely from Europe, to many nations in Africa. Without more data, we can't yet say which -- if any -- of these sparks resulted into local outbreaks. The [WHO reports](https://apps.who.int/iris/bitstream/handle/10665/331840/SITREP_COVID-19_WHOAFRO_20200422-eng.pdf) outbreaks of over 3400, 2800, and 500 cases in South Africa, Algeria, and Nigeria respectively.


<!-- ############ SLIDE BREAK ############# -->
<!-- This is left-side text 11-->
# [What you can do](https://nextstrain.org/ncov/2020-03-27?c=country&d=map&p=full)
#### ...as an individual
* Practice strict social distancing, especially if you are in a vulnerable group.
* Remember that even if you are not super vulnerable, many people around you are; follow these practices to protect others.
* Wear a mask (homemade works well) when in public.
* Wash your hands "like you just chopped a jalapeno and have to change a contact lens."  
* Stay home as much as possible -- especially  if you are sick; be prepared with extra supplies in case you need to self-quarantine.  
* If you are an employer, encourage your employees to work from home wherever possible.

#### ...as an official  
* Make testing free and broadly available.  
* Put strong social distancing measures in place.  
* Fund and implement extensive contact tracing efforts.  
* Financially support those impacted by social distancing measures.


<!-- This is the right-side text -->

```auspiceMainDisplayMarkdown
# Takeaways

#### There have been many separate introductions of SARS-CoV-2 to the African continent, primarily from Europe (although sampling bias may contribute to this inference).
<br><br>
#### 7 introductions to the DRC have led to at least 2 separate transmission chains circulating in Kinshasa.  
<br><br>
#### Similarly, 8 introductions to Senegal seeded local transmission chains in Dakar and Touba.  
<br><br>
#### SARS-CoV-2 has been introduced to Ghana at least 7 times, with local transmission in Greater Accra.
<br><br>
#### There have been scattered introductions to Algeria, Gambia, Nigeria, and South Africa. We don't yet have enough samples to infer local transmission from the sequence data.
```

<!-- ############ SLIDE BREAK ############# -->






<!-- ############ SLIDE BREAK ############# -->

<!-- This is left-side text 12-->
# [Scientific credit](https://nextstrain.org/ncov/2020-04-24?d=map&c=author)

We would like to acknowledge the amazing and timely work done by all scientists involved in this outbreak.
Only through the rapid sharing of genomic data and metadata are analyses such as these possible.
<br><br>
The specific sequences provided by each lab are [listed here](https://github.com/nextstrain/ncov/blob/52a133354c70d712a99f2d2a62116defe0f605ff/narratives/sit-rep_credits.md).
<br><br>
We also gratefully acknowledge GISAID for providing the platform through which these data can be uploaded and shared.

<!-- Do not need to translate institutions names -->
<!-- This is right-side text -->
```auspiceMainDisplayMarkdown

We are grateful for the data gathered by these originating labs.

* AIDS Vaccine Research Laboratories
* ARS Algarve - Laboratorio Laura Ayres
* AZ Department of Health Services
* AZ SPHL, Arizona Department of Health Services
* Akershus University Hospital, Department for Microbiology and Infectious Disease Control
* Alaska State Virology Laboratory
* Andersen Lab, The Scripps Research Institute
* Arizona Department of Health Services
* Arizona State University Health Services
* Auckland Hospital
* BCCDC Public Health Laboratory
* Bamrasnaradura Hospital
* Beijing Institute of Microbiology and Epidemiology
* Brian D. Allgood Army Community Hospital
* Bundeswehr Institute of Microbiology
* CH Barreiro Montijo
* CH Compiegne Laboratoire de Biologie
* CH Jean de Navarre Laboratoire de Biologie
* CH VN Gaia - Espinho
* CHBarreiro Montijo
* CHMT
* CHRU Bretonneau - Serv. Bacterio-Virol.
* CHRU Pontchaillou - Laboratoire de Virologie
* CHTMAD
* CHU - Hopital Cavale Blanche - Labo. de Virologie
* CHU Coimbra
* CHU Coimbra - Pediatrico
* CHU Gabriel Montpied
* CHU Purpan - Laboratoire de Virologie - Institut Federatif de Biologie
* CHUA - Faro
* CHULC - H Curry Cabral
* CHULC - H D Estefania
* CMIP
* CNR Virus des Infections Respiratoires - France SUD
* COMPLEJO ASISTENCIAL UNIVERSITARIO DE BURGOS
* CR&WISCO GENERAL HOSPITAL
* CT-Dr. Katherine A. Kelley State Public Health Lab
* Cabinet medical
* Cadham Provincial Laboratory
* California Department of Health
* California Department of Public Health
* Center for Virology, Medical University of Vienna
* Center of Medical Microbiology, Virology, and Hospital Hygiene, University of Duesseldorf
* Centers for Disease Control, R.O.C. (Taiwan)
* Central Virology Laboratory
* Centre Hositalier Universitaire de Rouen Laboratoire de Virologie
* Centre Hospitalier Compiegne Laboratoire de Biologie
* Centre Hospitalier Lucien Hussel
* Centre Hospitalier Regional Universitaire de Nantes Laboratoire de Virologie
* Centre Hospitalier Rene Dubois Laboratoire de Microbiologie - Bat A
* Centre Hospitalier Saint Joseph Saint Luc
* Centre Hospitalier de Bourg en Bresse
* Centre Hospitalier de Macon
* Centre Hospitalier de Valence
* Centre Hospitalier des Vals d'Ardeche
* Centre for Human and Zoonotic Virology (CHAZVY), College of Medicine University of Lagos/Lagos University Teaching Hospital (LUTH), part of the Laboratory Network of the Nigeria Centre for Disease Control (NCDC)
* Centre for Infectious Diseases and Microbiology - Public Health
* Centre for Infectious Diseases and Microbiology Laboratory Services
* Centre for Infectious Diseases and Microbiology Public Health
* Centre for Infectious Diseases and Microbiology- Public Health
* Centro Hospital do Porto, E.P.E. - H. Geral de Santo Antonio
* Centro Hospitalar e Universitario de Sao Joao, Porto
* Chan-Zuckerberg Biohub
* Charite Universitatsmedizin Berlin, Institute of Virology; Institut fur Mikrobiologie der Bundeswehr, Munich
* Chiba Prefectural Institute of Public Health
* Chiu Laboratory, University of California, San Francisco
* Clinica Alemana de Santiago, Chile
* Clinica Santa Maria, Santiago, Chile
* Clinical Diagnostics Laboratory, Diagnostic & Experimental Pathology, Lilly Research Laboratories
* Clinical Microbiology Lab
* Clinique AVERAY LA BROUSTE, Med. Polyvalente
* Connecticut State Department of Public Health
* DC Public Health Lab/ Dept. of Forensic Sciences
* Dasman Diabetes Institute
* Dasman Diabetes Institute and Virology Laboratory Ministry of Health
* Department for Virology, Molecular Biology and Genome Research, R. G. Lugar Center for Public Health Research,  National Center for Disease Control and Public Health (NCDC) of Georgia.
* Department of Clinical Microbiology
* Department of Clinical Pathology, Pamela Youde Nethersole Eastern Hospital
* Department of Clinical Pathology, Tuen Mun Hospital
* Department of Clinical Pathology, Tuen Mun Hospital, 23 Tsing Chung Koon Road, Tuen Mun, N.T.
* Department of Infectious Diseases, Istituto Superiore di Sanita, Roma , Italy
* Department of Infectious Diseases, Istituto Superiore di Sanita, Rome, Italy
* Department of Infectious and Tropical Diseases, Bichat Claude Bernard Hospital, Paris
* Department of Internal Medicine, Triemli Hospital
* Department of Laboratory Medicine, National Taiwan University Hospital
* Department of Medical Microbiology, University Malaya Medical Centre
* Department of Microbiology, Faculty of Medicine, The Chinese University of Hong Kong, Hong Kong SAR, China
* Department of Microbiology, Institute for Viral Diseases, College of Medicine, Korea University
* Department of Microbiology, PathWest QEII Medical Centre
* Department of Pathology, Princess Margaret Hospital
* Department of Pathology, Toshima Hospital
* Department of Pathology, United Christian Hospital
* Department of Pathology, University of Cambridge
* Department of Virology III, National Institute of Infectious Diseases
* Department of Virology and Immunology, University of Helsinki and Helsinki University Hospital, Huslab Finland
* Department of Virus and Microbiological Special diagnostics, Statens Serum Institut, Copenhagen, Denmark.
* Department of microbiology laboratory,Anhui Provincial Center for Disease Control and Prevention
* Dept. of Pathology, National Institute of Infectious Diseases
* Dept. of Virology III, National Institute of Infectious Diseases
* Dienst Gezondheid & Jeugd Zuid-Holland Zuid
* Division of Consolidated Laboratories
* Division of Consolidated Laboratories Services
* Division of Consolidated Laboratory Services
* Division of Infectious Diseases, Department of Internal Medicine, Korea University College of Medicine
* Division of Infectious Diseases, University Hospital Zurich
* Division of Viral Diseases, Center for Laboratory Control of Infectious Diseases, Korea Centers for Diseases Control and Prevention
* Dr. Georges-L.-Dumont University Hospital Centre
* Dunedin Hospital
* Dutch COVID-19 response team
* E. Gulbja Laboratorija
* EHPAD - Residences les Cedres
* ErasmusMC
* FL Bur. of Public Health Laboratories-Jacksonville
* FL Bureau of Health Laboratories Tampa
* FL Bureau of Public Health Laboratories-Miami
* FL Bureau of Public Health Laboratories-Tampa
* FUNDACION JIMENEZ DIAZ
* Forde Hospital  Department of Microbiology
* Foundation Elisabeth-Tweesteden Ziekenhuis
* Foundation Pamm
* Fujian Center for Disease Control and Prevention
* Fundacion Jimenez Diaz
* Furst Medical Laboratory
* GA Department of Public Health
* GA Department of Public Health Laboratory
* GH Les Portes du Sud
* Geelong Centre for Emerging Infectious Diseases
* General Hospital of Central Theater Command of People's Liberation Army of China
* Gorgas Memorial Institute for Health Studies
* Guangdong Provincial Center for Diseases Control and Prevention; Guangdong Provincial Public Health
* Guangdong Provincial Center for Diseases Control and Prevention; Guangdong Provinical Public Health
* Guangdong Provincial Center for Diseases Control and Prevention;Guangdong Provincial Institute of Public Health
* Guangdong Provincial Institution of Public Health, Guangdong Provinical Center for Disease Control and Prevention
* Gundersen Molecular Diagnostic Laboratory
* Gundersen Molecular Diagnostics Laboratory
* H Beatriz Angelo
* H Braga
* H Dr Nelio Mendonca - Funchal
* H Dr. Nelio Mendonca - Funchal
* H Evora
* H Garcia de Orta
* H Guimaraes
* H Santarem
* HI Dept. of Health, State Laboratories Division
* HOSPITAL CLINIC
* HOSPITAL DE CRUCES.
* HOSPITAL GENERAL DE SEGOVIA
* HOSPITAL SANTA MARIA NAI
* HOSPITAL TXAGORRITXU
* HOSPITAL UNIVERSITARIO LA PAZ
* HOSPITAL UNIVERSITARIO VIRGEN DE LAS NIEVES
* HSE Ilha Terceira - Angra do Heroismo
* HUS Diagnostiikkakeskus, Hallinto
* Hangzhou Center for Disease Control and Prevention
* Hangzhou Center for Disease and Control Microbiology Lab
* Hangzhou Center for Diseases Control and Prevention
* Harborview Medical Center
* Health Board Laboratory of Communicable Diseases
* Hong Kong Department of Health
* Hopital Instruction des Armees - BEGIN
* Hopital Prive de l'Est Lyonnais
* Hopital Robert Debre Laboratoire de Virologie
* Hopital franco britannique - Laboratoire
* Hopital franco britannique - Service des Urgences
* Hopitaux universitaires de Geneve Laboratoire de Virologie
* Hospital General Regional No.66, Ciudad Juarez, Chihuahua.
* Hospital General y Universitario de Guadalajara
* Hospital Israelita Albert Einstein
* Hospital Prof. Doutor Fernando Fonseca, EPE
* Hospital San Pedro
* Hospital Sao Joaquim Beneficencia Portuguesa
* Hospital Universitari Germans Trias i Pujol(HUGTiP)/Fundacio Lluita contra la SIDA (FLSida)/IRTA-CReSA
* Hospital Universitari Vall d'Hebron (HUVH) - Vall d'Hebron Research Institute (VHIR)
* Hospital Universitario 12 de Octubre
* Hospital Universitario La Paz
* Hospital Universitario Ramon y Cajal
* Hospital Universitario Virgen de las Nieves
* Hospital Universitario de Canarias
* Hospital de Talca, Chile
* Hospital of Southern Norway - Kristiansand, Department of Medical Microbiology
* IA State Hygienic Laboratory
* IL Department of Public Health Chicago Laboratory
* IN State Department of Health Laboratory Services
* INMI Lazzaro Spallanzani IRCCS
* Illinois Department of Public Health Chicago Laboratory
* Indian Council of Medical Research - National Institute of Virology
* Indian Council of Medical Research-National Institute of Virology
* Indian Council of Medical Research-National Institute of Virology, Microbial Containment Complex
* Instirut Pasteur Dakar
* Institut Medico legal- Hop R. Poincare
* Institut Pasteur Dakar
* Institut des Agents Infectieux (IAI) Hospices Civils de Lyon
* Institut des Agents Infectieux (IAI), Hospices Civils de Lyon
* Institut pasteur Dakar
* Institute information  KU Leuven, Clinical and Epidemiological Virology
* Institute of Microbiology Universidad San Francisco de Quito
* Institute of Microbiology and Immunology, Faculty of Medicine, University of Ljubljana
* Institute of Microbiology, Universidad San Francisco de Quito
* Institute of Pathogen Biology, Chinese Academy of Medical Sciences & Peking Union Medical College
* Institute of Viral Disease Control and Prevention, China CDC
* Institute of Virology, Biomedical Research Center of the Slovak Academy of Sciences, Bratislava; Public Health Authority of the Slovak Republic, Bratislava
* Instituto Nacional de Ciencias Medicas y Nutricion Salvador Zubiran
* Instituto Nacional de Enfermedades Respiratorias
* Instituto Nacional de Salud
* Instituto Nacional de Saude (INSA)
* Instituto Sabin
* Instituto de Diagnostico y Referencia Epidemiologicos
* Ishikawa Prefectural Institute of Public Health and Environmental Science
* JABER AL AHMAD AL SABAH HOSPITAL  KUWAIT CITY
* Jaber Al Ahmad Al Sabah Hospital
* Japanese Quarantine Stations
* Jiangxi Province Center for Disease Control and Prevention
* Jiangxi province Center for Disease Control and Prevention
* Jingzhou Center for Disease Control and Prevention
* KS Health and Environmental Laboratories
* KU Leuven, Clincal and Epidemiological Virology
* KU Leuven, Clinical and Epidemiological Virology
* Klinik Hirslanden Zurich
* Klinisk mikrobiologi, Region Vasterbotten
* Kochi Prefectural Institute of Public Health
* Korea Centers for Disease Control & Prevention (KCDC) Center for Laboratory Control of Infectious Diseases Division of Viral Diseases
* L'Air du Temps
* LA Office of Public Health Laboratories
* LABM GH nord Essonne
* LACEN RJ - Laboratorio Central de Saude Publica Noel Nutels
* LACEN/ES - Laboratorio Central de Saude Publica do Espirito Santo
* Lab voor klinische biologie
* Labo BM - Site de Juvisy - Hopital General
* Laboiratorio Fleury
* Laboratoire National de Sante
* Laboratoire National de Sante, Microbiology, Virology
* Laboratoire Nationale de Sante, Microbiology, Virology
* Laboratoire de Virologie Institut de Virologie - INSERM U 1109 Hopitaux Universitaires de Strasbourg
* Laboratoire de Virologie, HUG
* Laboratorio Central de Saude Publica Professor Goncalo Moniz  LACEN/BA
* Laboratorio Estatal de Salud Publica del Estado de Mexico
* Laboratorio Estatal de Salud Publica del Estado de Puebla
* Laboratorio Estatal de Salud Publica del Estado de Queretaro
* Laboratorio Hermes Pardini
* Laboratorio Simili
* Laboratorio de Ecologia de Doencas Transmissiveis na Amazonia, Instituto Leonidas e Maria Deane - Fiocruz Amazonia
* Laboratorio de Referencia Nacional de Virus Respiratorio. Instituto Nacional de Salud. Peru
* Laboratorio de Referencia Nacional de Virus Respiratorios. Instituto Nacional de Salud Peru
* Laboratorio di Microbiologia e Virologia, Universita Vita-Salute San Raffaele, Milano
* Laboratory Medicine
* Laboratory of Infectious Diseases, Department of Biomedical and Clinical Sciences L. Sacco, University of Milan
* Laboratory of Microbiology, Department of Medicine, National and Kapodistrian University of Athens, Greece
* Laboratory of Molecular Genetics, 2nd Faculty of Medicine, Charles University in Prague, Prague, Czech Republic
* Laboratory of Molecular Virology International Center for Genetic Engineering and Biotechnology (ICGEB)
* Laboratory of Molecular Virology International Center fro Genetic Engineering and Biotechnology (ICGEB)
* Laboratory of Molecular Virology, Pontificia Universidad Catolica de Chile
* Lapland Central Hospital
* Le Chateau de Seine-Port
* MA State Public Health Laboratory
* MD DOH Laboratories Administration
* MHC Brabant Zuidoost
* MHC Drente
* MHC Flevoland
* MHC Gooi & Vechtstreek
* MHC Haaglanden
* MHC Hart voor Brabant
* MHC Kennemerland
* MHC Rotterdam-Rijnmond
* MHC Utrecht
* MHC West-Brabant
* MN PHL Division, Minnesota Department of Health
* MO State Public Health Laboratory
* MSHS Clinical Microbiology Laboratories
* Massachusetts Department of Public Health
* Mater Pathology
* Max von Pettenkofer Institute, Virology, National Reference Center for Retroviruses, LMU Munich
* Microbial Genomics Laboratory, Institut Pasteur Monteivdeo
* Microbial Genomics Laboratory, Institut Pasteur Montevideo
* Microbial Genomics Laboratory, Institut Pasteur Montevideo, Uruguay
* Microbiological Diagnostic Unit Public Health Laboratory
* Ministry of Health Turkey
* Minnesota Department of Health, Public Health Laboratory
* Molecular Biology and Biotechnology Lab II
* Molecular Diagnostic Services
* Molecular Diagnostic Services and FLowpath
* Monash Medical Centre
* Motol University Hospital
* NC State Laboratory of Public Health
* NE Public Health Laboratory
* NH Department of Health and Human Services Public Health Labs
* NH Dept. of Health and Human Services Public Health Labs
* NHC Key laboratory of Enteric Pathogenic Microbiology, Institute of Pathogenic Microbiology
* NIC Viral Respiratory Unit - Institut Pasteur of Algeria
* NJ Public Health and Environmental Laboratories
* NMIMR, Department of Virology
* NRL for Influenza, Centrum Epidemiology and Microbiology of National Institute of Public Health, Czech Republic
* NV State Public Health Laboratory
* NV-Southern Nevada Public Health Laboratory
* NYC Department of Health and Mental Hygiene
* NYU Langone Health
* National Centre for Infectious Diseases
* National Influenza Center - Instituto Adolfo Lutz
* National Influenza Center - National Institute of Hygiene and Epidemiology (NIHE)
* National Influenza Center, Indian Council of Medical Research - National Institute of Virology
* National Influenza Center, National Institute of Hygiene and Epidemiology (NIHE)
* National Influenza Centre, National Public Health Laboratory, Kathmandu, Nepal
* National Institute for Communicable Diseases of the National Health Laboratory Service
* National Institute for Viral Disease Control and Prevention, China CDC
* National Public Health Laboratory
* National Public Health Laboratory, National Centre for Infectious Diseases
* National Public Health Surveillance Laboratory, Vilnius, Lithuania
* Nordland Hospital - Bodo,  Laboratory Department, Molecular Biology Unit
* OH Department of Health Laboratory
* OR State PHL-Virology/Immunology Section
* Ochsner Health
* Oregon State Public Health- Virology section
* Oslo University Hospital, Department of Medical Microbiology
* Ospedale Civile Castel Di Sangro
* Ospedale Civile Giuseppe Mazzini
* Ospedale Civile Giuseppe Mazzini, Teramo
* Ospedale Regionale San Salvatore
* Ospedale San Liberatore di Atri
* Ostfold Hospital Trust -Kalnes Centre for Laboratory Medicine Section for gene technology and infection serology
* PA Department of Health, Bureau of Laboratories
* Parc des Dames
* PathWest Laboratory Medicine WA
* Pathology North
* Pathology Queensland
* Presidio Ospedaliero "S. Spirito" - PESCARA
* Presidio ospedaliero "Santo Spirito"
* Prince of Wales Hospital
* Providence Regional Medical Center
* Public Health Laboratory
* Public Health Laboratory, Saudi CDC
* Public Health Ontario
* Public Health Ontario Laboratories
* Public Health Ontario Laboratory
* Queen Elizabeth II Health Science Centre
* Queens Medical Centre, Clinical Microbiology Department / DeepSeq Nottingham
* R. G. Lugar Center for Public Health Research,  National Center for Disease Control and Public Health (NCDC) of Georgia.
* RI State Health Laboratories
* RI State Health Laboratory
* RIVM
* Ramathibodi Hospital
* Regional Virus Laboratory, Belfast
* Residence Eleusis
* Residence Villa Caroline
* Residence de maintenon
* Residence les Marines
* Respiratory Virus Unit, Microbiology Services Colindale, Public Health England
* Rockhampton Base Hospital
* Roy Romanow Provincial Laboratory
* Royal Darwin Hospital
* Royal Darwin Hospital Pathology
* Russian State Collection of Viruses
* SC Dept of Health and Env. Control-Bureau of Laboratories
* SYNLAB Eesti OU
* Saitama Medical University
* Saitama Medical University Hospital
* Saitama Prefectural Institute of Public Health
* Santa Clara County Public Health Department
* Seattle Flu Study
* Second Hospital of Anhui Medical University
* Secretaria de Salud Medellin
* Sentinelles network
* Serology, Virology and OTDS Laboratories (SAViD), NSW Health Pathology Randwick
* Service de Biologie Medicale - BP 125
* Service de Biologie clinique
* Service des Urgences
* Servicio Microbiologia, Hospital Clinico Universitario, Valencia
* Servicio Microbiologia. Hospital Clinico Universitario. Valencia.
* Servicio Virosis Respiratorias-Departamento Virologia-INEI
* Servicio de Microbiologia. Consorcio Hospital General Universitario de Valencia
* Servicio de Microbiologia. Hospital Clinico Universitario de Valencia
* Shandong Provincial Center for Disease Control and Prevention
* Shanghai Public Health Clinical Center, Shanghai Medical College, Fudan University
* Shenzhen Key Laboratory of Pathogen and Immunity, National Clinical Research Center for Infectious Disease, Shenzhen Third People's Hospital
* Shenzhen Third People's Hospital
* Singapore General Hospital
* Singapore General Hospital, Molecular Laboratory, Division of Pathology
* Sir M P Shah Government Medical College
* Sir M P Shah Government Medical College, Jamnagar
* Sorbonne Universite, Inserm et Assistance Publique-Hopitaux de Paris (Pitie Salpetriere)
* South China Agricultural University
* State Health Office Baden-Wuerttemberg
* State Key Laboratory for Diagnosis and Treatment of Infectious Diseases, National Clinical Research Center for Infectious Diseases, First Affiliated Hospital, Zhejiang University School of Medicine, Hangzhou, China 310003
* State Key Laboratory for Diagnosis and Treatment of Infectious Diseases, National Clinical Research Center for Infectious Diseases, First Affiliated Hospital, Zhejiang University School of Medicine, Hangzhou, China. 310003
* State Key Laboratory for Emerging Infectious Diseases Department of Microbiology Li Ka Shing Faculty of Medicine The University of Hong Kong
* State Key Laboratory of Respiratory Disease, National Clinical Research Center for Respiratory Disease, Guangzhou Institute of Respiratory Health, the First Affiliated Hospital of Guangzhou Medical University
* Stavanger University Hospital, Department of Medical Microbiology
* Sullivan Nicolaides Pathology
* TGen North
* TSGH-CP molecular lab
* Tai Lung Veterinary Laboratory, Agriculture, Fisheries and Conservation Department
* Taiwan Centers for Disease Control
* Texas DSHS Lab Services
* Texas Department of State Health Services
* Texas Department of State Health Services Lab Services
* The Central Hospital Of Wuhan
* The Chaim Sheba Medical Center
* The National Institute of Public Health Center for Epidemiology and Microbiology
* The National Laboratory of Health, Environment and Food, Maribor, Slovenia
* The National University Hospital of Iceland
* The Ohio State University
* The Ohio State University Wexner Medical Center
* The Republican Research and Practical Center for Epidemiology and Microbiology
* The University of Hong Kong - Shenzhen Hospital
* Tianmen Center for Disease Control and Prevention
* UCD National Virus Reference Laboratory
* ULSS9 Distretto di Bussolengo
* UT-Unified State Labs: Public Health Utah DOH
* UW Virology Lab
* Unilabs Laboratory Medicine
* Union Hospital of Tongji Medical College, Huazhong University of Science and Technology
* Universidade Federal do Rio de Janeiro
* Universidade Federal do Rio de Janeiro - UFRJ
* University Hospital Basel, Clinical Virology
* University Hospital of Northern Norway, Department for Microbiology and Infectious Disease Control
* University of Wisconsin - Madison AIDS Vaccine Research Laboratories
* University of Wisconsin - Madison: Influenza Research Institute
* University of Wisconsin-Madison AIDS Vaccine Research Laboratories
* University of Wisconsin-Madison AIDS Vaccine Research Laboratory
* University of Wisconsin-Madison, AIDS Vaccine Research Laboratories
* Unknown
* Utah Public Health Laboratory
* VA DCLS
* VA-Division of Consolidated Laboratory Services
* Vaccine Research, Development and Application Center, Erciyes University
* Valley Medical Center
* Vestfold Hospital, Tonsberg  Department of Microbiology
* Victorian Infectious Diseases Reference Laboratory (VIDRL)
* Viral Respiratory Lab, National Institute for Biomedical Research (INRB)
* Virginia Division of Consolidated Laboratories
* Virginia Division of Consolidated Laboratory Services
* ViroGenetics - BSL3 Laboratory of Virology; Human Genome Variation Research Group & Genomics Centre MCB; Bioinformatics Research Group  Department of Virology
* Virological Research Group, Szentagothai Research Centre
* Virological Research Group, Szentagothai Research Centre, University of Pecs
* Virology Department, Royal Infirmary of Edinburgh, NHS Lothian
* Virology Department, Royal Infirmary of Edinburgh, NHS Lothian / School of Biological Sciences, University of Edinburgh / Institute of Genetics and Molecular Medicine, University of Edinburgh
* Virology Department, Sheffield Teaching Hospitals NHS Foundation Trust
* Virology Laboratory, Department of Biomedical Sciences and Public Health, University Politecnica delle Marche
* Virology Unit, Institut Pasteur du Cambodge.
* Virology laboratory Ministry of Health Kuwait sequenced at Dasman Diabetes Institute
* WA State Department of Health
* WHO National Influenza Centre Russian Federation
* Wadsworth Center, New York State Department of Health
* Wadsworth Center, New York State Department.of Health
* Wales Specialist Virology Centre
* Washington State Department of Health
* Washington State Public Health Lab
* Weifang Center for Disease Control and Prevention
* Wellington Hospital
* West of Scotland Specialist Virology Centre, NHSGGC
* West of Scotland Specialist Virology Centre, NHSGGC / MRC-University of Glasgow Centre for Virus Research
* Wisconsin Department of Health Services
* Wuhan Fourth Hospital
* Wuhan Institute of Virology, Chinese Academy of Sciences
* Wuhan Jinyintan Hospital
* Wuhan Lung Hospital
* Wyoming Public Health Laboratory
* Yale COVID-19 Biorepository
* Yale Clinical Virology Laboratory
* Yongchuan District Center for Disease Control and Prevention
* Zhejiang Provincial Center for Disease Control and Prevention
* Zhongxian Center for Disease Control and Prevention
* deCODE genetics
* n/a
* ACT Pathology, The Canberra Hospital
* AIDS Vaccine Research Laboratories
* ARS Algarve - Laboratorio Laura Ayres
* AZ Department of Health Services
* AZ SPHL, Arizona Department of Health Services
* Akershus University Hospital, Department for Microbiology and Infectious Disease Control
* Alaska State Virology Laboratory
* Andersen Lab, The Scripps Research Institute
* Arizona Department of Health Services
* Arizona State University Health Services
* Auckland Hospital
* BCCDC Public Health Laboratory
* Bamrasnaradura Hospital
* Beijing Institute of Microbiology and Epidemiology
* Brian D. Allgood Army Community Hospital
* Bundeswehr Institute of Microbiology
* CH Barreiro Montijo
* CH Compiegne Laboratoire de Biologie
* CH Jean de Navarre Laboratoire de Biologie
* CH Jeanne de Navarre Laboratoire de Biologie
* CH VN Gaia - Espinho
* CHBarreiro Montijo
* CHMT
* CHRU Bretonneau - Serv. Bacterio-Virol.
* CHRU Pontchaillou - Laboratoire de Virologie
* CHTMAD
* CHU - Hopital Cavale Blanche - Labo. de Virologie
* CHU Coimbra
* CHU Coimbra - Pediatrico
* CHU Gabriel Montpied
* CHU Purpan - Laboratoire de Virologie - Institut Federatif de Biologie
* CHUA - Faro
* CHULC - H Curry Cabral
* CHULC - H D Estefania
* CMIP
* CNR Virus des Infections Respiratoires - France SUD
* COMPLEJO ASISTENCIAL UNIVERSITARIO DE BURGOS
* CR&WISCO GENERAL HOSPITAL
* CT-Dr. Katherine A. Kelley State Public Health Lab
* Cabinet Medical
* Cabinet medical
* Cadham Provincial Laboratory
* California Department of Health
* California Department of Public Health
* Center for Virology, Medical University of Vienna
* Center of Medical Microbiology, Virology, and Hospital Hygiene, University of Duesseldorf
* Centers for Disease Control, R.O.C. (Taiwan)
* Central Virology Laboratory
* Centre Hositalier Universitaire de Rouen Laboratoire de Virologie
* Centre Hospitalier Compiegne Laboratoire de Biologie
* Centre Hospitalier Lucien Hussel
* Centre Hospitalier Regional Universitaire de Nantes Laboratoire de Virologie
* Centre Hospitalier Rene Dubois Laboratoire de Microbiologie - Bat A
* Centre Hospitalier Saint Joseph Saint Luc
* Centre Hospitalier de Bourg en Bresse
* Centre Hospitalier de Macon
* Centre Hospitalier de Valence
* Centre Hospitalier des Vals d'Ardeche
* Centre for Dengue Research
* Centre for Human and Zoonotic Virology (CHAZVY), College of Medicine University of Lagos/Lagos University Teaching Hospital (LUTH), part of the Laboratory Network of the Nigeria Centre for Disease Control (NCDC)
* Centre for Infectious Diseases and Microbiology - Public Health
* Centre for Infectious Diseases and Microbiology Laboratory Services
* Centre for Infectious Diseases and Microbiology Public Health
* Centre for Infectious Diseases and Microbiology- Public Health
* Centro Hospital do Porto, E.P.E. - H. Geral de Santo Antonio
* Centro Hospitalar e Universitario de Sao Joao, Porto
* Chan-Zuckerberg Biohub
* Charite Universitatsmedizin Berlin, Institute of Virology; Institut fur Mikrobiologie der Bundeswehr, Munich
* Chiba Prefectural Institute of Public Health
* Chiu Laboratory, University of California, San Francisco
* Clinica Alemana de Santiago, Chile
* Clinica Santa Maria, Santiago, Chile
* Clinical Diagnostics Laboratory, Diagnostic & Experimental Pathology, Lilly Research Laboratories
* Clinical Microbiology Lab
* Clinique AVERAY LA BROUSTE, Med. Polyvalente
* Connecticut State Department of Public Health
* DC Public Health Lab/ Dept. of Forensic Sciences
* Dasman Diabetes Institute
* Dasman Diabetes Institute and Virology Laboratory Ministry of Health
* Department for Virology, Molecular Biology and Genome Research, R. G. Lugar Center for Public Health Research,  National Center for Disease Control and Public Health (NCDC) of Georgia.
* Department of Clinical Laboratory, the First People's Hospital of Yunnan Province
* Department of Clinical Microbiology
* Department of Clinical Pathology, Pamela Youde Nethersole Eastern Hospital
* Department of Clinical Pathology, Tuen Mun Hospital
* Department of Clinical Pathology, Tuen Mun Hospital, 23 Tsing Chung Koon Road, Tuen Mun, N.T.
* Department of Infectious Diseases, Istituto Superiore di Sanita, Roma , Italy
* Department of Infectious Diseases, Istituto Superiore di Sanita, Rome, Italy
* Department of Infectious and Tropical Diseases, Bichat Claude Bernard Hospital, Paris
* Department of Internal Medicine, Triemli Hospital
* Department of Laboratory Medicine, National Taiwan University Hospital
* Department of Medical Microbiology, University Malaya Medical Centre
* Department of Microbiology, Faculty of Medicine, The Chinese University of Hong Kong, Hong Kong SAR, China
* Department of Microbiology, Institute for Viral Diseases, College of Medicine, Korea University
* Department of Microbiology, PathWest QEII Medical Centre
* Department of Pathology, Princess Margaret Hospital
* Department of Pathology, Toshima Hospital
* Department of Pathology, United Christian Hospital
* Department of Pathology, University of Cambridge
* Department of Virology III, National Institute of Infectious Diseases
* Department of Virology and Immunology, University of Helsinki and Helsinki University Hospital, Huslab Finland
* Department of Virus and Microbiological Special diagnostics, Statens Serum Institut, Copenhagen, Denmark.
* Department of microbiology laboratory,Anhui Provincial Center for Disease Control and Prevention
* Dept. of Pathology, National Institute of Infectious Diseases
* Dept. of Virology III, National Institute of Infectious Diseases
* Dienst Gezondheid & Jeugd Zuid-Holland Zuid
* District Surveillence Unit
* Division of Consolidated Laboratories
* Division of Consolidated Laboratories Services
* Division of Consolidated Laboratory Services
* Division of Infectious Diseases, Department of Internal Medicine, Korea University College of Medicine
* Division of Infectious Diseases, University Hospital Zurich
* Division of Viral Diseases, Center for Laboratory Control of Infectious Diseases, Korea Centers for Diseases Control and Prevention
* Dr. Georges-L.-Dumont University Hospital Centre
* Dunedin Hospital
* Dutch COVID-19 response team
* E. Gulbja Laboratorija
* EHPAD - Residences les Cedres
* ErasmusMC
* FL Bur. of Public Health Laboratories-Jacksonville
* FL Bureau of Health Laboratories Tampa
* FL Bureau of Public Health Laboratories-Miami
* FL Bureau of Public Health Laboratories-Tampa
* FSBSI "Chumakov Federal Scientific Center for Research and Development of Immune-and-Biological Products of Russian Academy of Sciences"
* FUNDACION JIMENEZ DIAZ
* Forde Hospital  Department of Microbiology
* Foundation Elisabeth-Tweesteden Ziekenhuis
* Foundation Pamm
* Fujian Center for Disease Control and Prevention
* Fundacion Jimenez Diaz
* Furst Medical Laboratory
* GA Department of Public Health
* GA Department of Public Health Laboratory
* GH Les Portes du Sud
* GH Nord Essonne Service de Biologie clinique
* Geelong Centre for Emerging Infectious Diseases
* General Hospital of Central Theater Command of People's Liberation Army of China
* Genomic Laboratory (GLAB) (Conjoint lab of Health Directorate of Istanbul and Istanbul Technical University)
* Gorgas Memorial Institute for Health Studies
* Guangdong Provincial Center for Diseases Control and Prevention; Guangdong Provincial Public Health
* Guangdong Provincial Center for Diseases Control and Prevention; Guangdong Provinical Public Health
* Guangdong Provincial Center for Diseases Control and Prevention;Guangdong Provincial Institute of Public Health
* Guangdong Provincial Institution of Public Health, Guangdong Provinical Center for Disease Control and Prevention
* Gundersen Molecular Diagnostic Laboratory
* Gundersen Molecular Diagnostics Laboratory
* H Beatriz Angelo
* H Braga
* H Dr Nelio Mendonca - Funchal
* H Dr. Nelio Mendonca - Funchal
* H Evora
* H Garcia de Orta
* H Guimaraes
* H Santarem
* HI Dept. of Health, State Laboratories Division
* HOSPITAL CLINIC
* HOSPITAL DE CRUCES.
* HOSPITAL GENERAL DE SEGOVIA
* HOSPITAL SANTA MARIA NAI
* HOSPITAL TXAGORRITXU
* HOSPITAL UNIVERSITARIO LA PAZ
* HOSPITAL UNIVERSITARIO VIRGEN DE LAS NIEVES
* HSE Ilha Terceira - Angra do Heroismo
* HUS Diagnostiikkakeskus, Hallinto
* Hangzhou Center for Disease Control and Prevention
* Hangzhou Center for Disease and Control Microbiology Lab
* Hangzhou Center for Diseases Control and Prevention
* Harborview Medical Center
* Health Board Laboratory of Communicable Diseases
* Health Sciences Technology Park, Avicena, 8, 18016 Granada. Spain
* Hematology Laboratory, Section of Molecular Diagnostics, University Clinical Centre, Medical University of Gdansk
* Hong Kong Department of Health
* Hopital Instruction des Armees - BEGIN
* Hopital Prive de l'Est Lyonnais
* Hopital Robert Debre Laboratoire de Virologie
* Hopital franco britannique - Laboratoire
* Hopital franco britannique - Service des Urgences
* Hopitaux universitaires de Geneve Laboratoire de Virologie
* Hospital General Regional No.66, Ciudad Juarez, Chihuahua.
* Hospital General y Universitario de Guadalajara
* Hospital Israelita Albert Einstein
* Hospital Prof. Doutor Fernando Fonseca, EPE
* Hospital San Pedro
* Hospital Sao Joaquim Beneficencia Portuguesa
* Hospital Universitari Germans Trias i Pujol(HUGTiP)/Fundacio Lluita contra la SIDA (FLSida)/IRTA-CReSA
* Hospital Universitari Vall d'Hebron (HUVH) - Vall d'Hebron Research Institute (VHIR)
* Hospital Universitario 12 de Octubre
* Hospital Universitario La Paz
* Hospital Universitario Ramon y Cajal
* Hospital Universitario Virgen de las Nieves
* Hospital Universitario de Canarias
* Hospital de Talca, Chile
* Hospital of Southern Norway - Kristiansand, Department of Medical Microbiology
* IA State Hygienic Laboratory
* IL Department of Public Health Chicago Laboratory
* IN State Department of Health Laboratory Services
* INMI Lazzaro Spallanzani IRCCS
* Illinois Department of Public Health Chicago Laboratory
* Indian Council of Medical Research - National Institute of Virology
* Indian Council of Medical Research-National Institute of Virology
* Indian Council of Medical Research-National Institute of Virology, Microbial Containment Complex
* Instirut Pasteur Dakar
* Institut Medico legal- Hop R. Poincare
* Institut Pasteur Dakar
* Institut des Agents Infectieux (IAI) Hospices Civils de Lyon
* Institut des Agents Infectieux (IAI), Hospices Civils de Lyon
* Institut pasteur Dakar
* Institute information  KU Leuven, Clinical and Epidemiological Virology
* Institute of Microbiology Universidad San Francisco de Quito
* Institute of Microbiology and Immunology, Faculty of Medicine, University of Ljubljana
* Institute of Microbiology, Universidad San Francisco de Quito
* Institute of Pathogen Biology, Chinese Academy of Medical Sciences & Peking Union Medical College
* Institute of Viral Disease Control and Prevention, China CDC
* Institute of Virology, Biomedical Research Center of the Slovak Academy of Sciences, Bratislava; Public Health Authority of the Slovak Republic, Bratislava
* Instituto Nacional de Ciencias Medicas y Nutricion Salvador Zubiran
* Instituto Nacional de Enfermedades Respiratorias
* Instituto Nacional de Salud
* Instituto Nacional de Saude (INSA)
* Instituto Oswaldo Cruz FIOCRUZ - Laboratory of Respiratory Viruses and Measles (LVRS)
* Instituto Sabin
* Instituto de Diagnostico y Referencia Epidemiologicos
* Ishikawa Prefectural Institute of Public Health and Environmental Science
* JABER AL AHMAD AL SABAH HOSPITAL  KUWAIT CITY
* Jaber Al Ahmad Al Sabah Hospital
* Japanese Quarantine Stations
* Jiangxi Province Center for Disease Control and Prevention
* Jiangxi province Center for Disease Control and Prevention
* Jingzhou Center for Disease Control and Prevention
* KS Health and Environmental Laboratories
* KU Leuven, Clincal and Epidemiological Virology
* KU Leuven, Clinical and Epidemiological Virology
* Klinik Hirslanden Zurich
* Klinisk mikrobiologi Orebro
* Klinisk mikrobiologi och vardhygien Halmstad
* Klinisk mikrobiologi, Region Vasterbotten
* Kochi Prefectural Institute of Public Health
* Korea Centers for Disease Control & Prevention (KCDC) Center for Laboratory Control of Infectious Diseases Division of Viral Diseases
* L'Air du Temps
* LA Office of Public Health Laboratories
* LABM GH nord Essonne
* LABM GH nord Essonne de Longjumeau - BP 125
* LACEN RJ - Laboratorio Central de Saude Publica Noel Nutels
* LACEN-AL - Laboratorio Central de Alagoas
* LACEN-BA - Laboratorio Central de Saude Publica Professor Goncalo Moniz
* LACEN-SC - Laboratorio Central de Santa Catarina
* LACEN/ES - Laboratorio Central de Saude Publica do Espirito Santo
* Lab voor klinische biologie
* Labo BM - Site de Juvisy - Hopital General
* Laboiratorio Fleury
* Laboratoire National de Sante
* Laboratoire National de Sante, Microbiology, Virology
* Laboratoire Nationale de Sante, Microbiology, Virology
* Laboratoire de Virologie Institut de Virologie - INSERM U 1109 Hopitaux Universitaires de Strasbourg
* Laboratoire de Virologie, HUG
* Laboratoriemedicin
* Laboratorio Central de Saude Publica Professor Goncalo Moniz  LACEN/BA
* Laboratorio Estatal de Salud Publica del Estado de Mexico
* Laboratorio Estatal de Salud Publica del Estado de Puebla
* Laboratorio Estatal de Salud Publica del Estado de Queretaro
* Laboratorio Hermes Pardini
* Laboratorio Simili
* Laboratorio de Ecologia de Doencas Transmissiveis na Amazonia, Instituto Leonidas e Maria Deane - Fiocruz Amazonia
* Laboratorio de Referencia Nacional de Virus Respiratorio. Instituto Nacional de Salud. Peru
* Laboratorio de Referencia Nacional de Virus Respiratorios. Instituto Nacional de Salud Peru
* Laboratorio di Microbiologia e Virologia, Universita Vita-Salute San Raffaele, Milano
* Laboratory Medicine
* Laboratory of Infectious Diseases, Department of Biomedical and Clinical Sciences L. Sacco, University of Milan
* Laboratory of Microbiology, Department of Medicine, National and Kapodistrian University of Athens, Greece
* Laboratory of Microbiology, Medical School, National and Kapodistrian University of Athens
* Laboratory of Molecular Biology, Diagnostyka sp. z o.o.
* Laboratory of Molecular Genetics, 2nd Faculty of Medicine, Charles University in Prague, Prague, Czech Republic
* Laboratory of Molecular Virology International Center for Genetic Engineering and Biotechnology (ICGEB)
* Laboratory of Molecular Virology International Center fro Genetic Engineering and Biotechnology (ICGEB)
* Laboratory of Molecular Virology, Pontificia Universidad Catolica de Chile
* Lapland Central Hospital
* Le Chateau de Seine-Port
* MA State Public Health Laboratory
* MD DOH Laboratories Administration
* MHC Brabant Zuidoost
* MHC Drente
* MHC Flevoland
* MHC Gooi & Vechtstreek
* MHC Haaglanden
* MHC Hart voor Brabant
* MHC Kennemerland
* MHC Rotterdam-Rijnmond
* MHC Utrecht
* MHC West-Brabant
* MN PHL Division, Minnesota Department of Health
* MO State Public Health Laboratory
* MRCG at LSHTM Genomics Lab
* MRCG at LSHTM Genomics lab
* MRCG at LSHTM Geomics lab
* MSHS Clinical Microbiology Laboratories
* Maison de Sante du Val d'Ormois
* Massachusetts Department of Public Health
* Mater Pathology
* Max von Pettenkofer Institute, Virology, National Reference Center for Retroviruses, LMU Munich
* Microbial Genomics Laboratory, Institut Pasteur Monteivdeo
* Microbial Genomics Laboratory, Institut Pasteur Montevideo
* Microbial Genomics Laboratory, Institut Pasteur Montevideo, Uruguay
* Microbiological Diagnostic Unit Public Health Laboratory
* Ministry of Health Turkey
* Ministry of Public Health (MoPH)
* Minnesota Department of Health, Public Health Laboratory
* Molecular Biology and Biotechnology Lab II
* Molecular Diagnostic Services
* Molecular Diagnostic Services and FLowpath
* Monash Medical Centre
* Motol University Hospital
* NC State Laboratory of Public Health
* NE Public Health Laboratory
* NH Department of Health and Human Services Public Health Labs
* NH Dept. of Health and Human Services Public Health Labs
* NHC Key laboratory of Enteric Pathogenic Microbiology, Institute of Pathogenic Microbiology
* NIC Viral Respiratory Unit - Institut Pasteur of Algeria
* NJ Public Health and Environmental Laboratories
* NMIMR, Department of Virology
* NRL for Influenza, Centrum Epidemiology and Microbiology of National Institute of Public Health, Czech Republic
* NV State Public Health Laboratory
* NV-Southern Nevada Public Health Laboratory
* NYC Department of Health and Mental Hygiene
* NYU Langone Health
* National Centre for Infectious Diseases
* National Influenza Center - Instituto Adolfo Lutz
* National Influenza Center - National Institute of Hygiene and Epidemiology (NIHE)
* National Influenza Center, Indian Council of Medical Research - National Institute of Virology
* National Influenza Center, National Institute of Hygiene and Epidemiology (NIHE)
* National Influenza Centre, National Public Health Laboratory, Kathmandu, Nepal
* National Institute for Communicable Diseases of the National Health Laboratory Service
* National Institute for Viral Disease Control and Prevention, China CDC
* National Public Health Laboratory
* National Public Health Laboratory, National Centre for Infectious Diseases
* National Public Health Surveillance Laboratory, Vilnius, Lithuania
* Nebraska Public Health Laboratory
* NewYork-Presbyterian & Mason Lab
* Nordland Hospital - Bodo,  Laboratory Department, Molecular Biology Unit
* OH Department of Health Laboratory
* OR State PHL-Virology/Immunology Section
* Ochsner Health
* Oregon State Public Health- Virology section
* Oslo University Hospital, Department of Medical Microbiology
* Ospedale Civile Castel Di Sangro
* Ospedale Civile Giuseppe Mazzini
* Ospedale Civile Giuseppe Mazzini, Teramo
* Ospedale Civile S. Liberatore di Atri
* Ospedale Regionale San Salvatore
* Ospedale San Liberatore di Atri
* Ostfold Hospital Trust -Kalnes Centre for Laboratory Medicine Section for gene technology and infection serology
* PA Department of Health, Bureau of Laboratories
* Parc des Dames
* PathWest Laboratory Medicine WA
* Pathology North
* Pathology Queensland
* Presidio Ospedaliero "S. Spirito" - PESCARA
* Presidio Ospedaliero Santo Spirito
* Presidio ospedaliero "Santo Spirito"
* Prince of Wales Hospital
* Providence Regional Medical Center
* Public Health Laboratory
* Public Health Laboratory, Saudi CDC
* Public Health Ontario
* Public Health Ontario Laboratories
* Public Health Ontario Laboratory
* Queen Elizabeth II Health Science Centre
* Queens Medical Centre, Clinical Microbiology Department / DeepSeq Nottingham
* R. G. Lugar Center for Public Health Research,  National Center for Disease Control and Public Health (NCDC) of Georgia.
* RI State Health Laboratories
* RI State Health Laboratory
* RIVM
* Ramathibodi Hospital
* Regional Virus Laboratory, Belfast
* Residence Eleusis
* Residence Villa Caroline
* Residence de maintenon
* Residence les Marines
* Respiratory Virus Unit, Microbiology Services Colindale, Public Health England
* Rockhampton Base Hospital
* Roy Romanow Provincial Laboratory
* Royal Darwin Hospital
* Royal Darwin Hospital Pathology
* Russian State Collection of Viruses
* SC Dept of Health and Env. Control-Bureau of Laboratories
* SRC VB "Vector", "Collection of microorganisms" Department.
* SYNLAB Eesti OU
* Saitama Medical University
* Saitama Medical University Hospital
* Saitama Prefectural Institute of Public Health
* Santa Clara County Public Health Department
* Seattle Flu Study
* Second Hospital of Anhui Medical University
* Secretaria de Salud Medellin
* Sentinelles network
* Serology, Virology and OTDS Laboratories (SAViD), NSW Health Pathology Randwick
* Service de Biologie Medicale - BP 125
* Service de Biologie clinique
* Service des Urgences
* Servicio Microbiologia, Hospital Clinico Universitario, Valencia
* Servicio Microbiologia. Hospital Clinico Universitario. Valencia.
* Servicio Virosis Respiratorias-Departamento Virologia-INEI
* Servicio de Microbiologia. Consorcio Hospital General Universitario de Valencia
* Servicio de Microbiologia. Hospital Clinico Universitario de Valencia
* Shandong First Medical University & Shandong Academy of Medical Sciences
* Shandong Provincial Center for Disease Control and Prevention
* Shanghai Public Health Clinical Center, Shanghai Medical College, Fudan University
* Shenzhen Key Laboratory of Pathogen and Immunity, National Clinical Research Center for Infectious Disease, Shenzhen Third People's Hospital
* Shenzhen Third People's Hospital
* Singapore General Hospital
* Singapore General Hospital, Molecular Laboratory, Division of Pathology
* Sir M P Shah Government Medical College
* Sir M P Shah Government Medical College, Jamnagar
* Sorbonne Universite, Inserm et Assistance Publique-Hopitaux de Paris (Pitie Salpetriere)
* South China Agricultural University
* State Health Office Baden-Wuerttemberg
* State Key Laboratory for Diagnosis and Treatment of Infectious Diseases, National Clinical Research Center for Infectious Diseases, First Affiliated Hospital, Zhejiang University School of Medicine, Hangzhou, China 310003
* State Key Laboratory for Diagnosis and Treatment of Infectious Diseases, National Clinical Research Center for Infectious Diseases, First Affiliated Hospital, Zhejiang University School of Medicine, Hangzhou, China. 310003
* State Key Laboratory for Emerging Infectious Diseases Department of Microbiology Li Ka Shing Faculty of Medicine The University of Hong Kong
* State Key Laboratory of Respiratory Disease, National Clinical Research Center for Respiratory Disease, Guangzhou Institute of Respiratory Health, the First Affiliated Hospital of Guangzhou Medical University
* State Research Center of Virology and Biotechnology VECTOR, Department of Collection of Microorganisms
* Stavanger University Hospital, Department of Medical Microbiology
* Sullivan Nicolaides Pathology
* TGen North
* TSGH-CP molecular lab
* Tai Lung Veterinary Laboratory, Agriculture, Fisheries and Conservation Department
* Taiwan Centers for Disease Control
* Texas DSHS Lab Services
* Texas Department of State Health Services
* Texas Department of State Health Services Lab Services
* The Central Hospital Of Wuhan
* The Chaim Sheba Medical Center
* The First Affiliated Hospital of Guangzhou Medical University
* The National Institute of Public Health Center for Epidemiology and Microbiology
* The National Laboratory of Health, Environment and Food, Maribor, Slovenia
* The National University Hospital of Iceland
* The Ohio State University
* The Ohio State University Wexner Medical Center
* The Public Health Agency of Sweden
* The Republican Research and Practical Center for Epidemiology and Microbiology
* The University of Hong Kong - Shenzhen Hospital
* Tianmen Center for Disease Control and Prevention
* UCD National Virus Reference Laboratory
* UCSF Clinical Microbiology Laboratory
* ULSS9 Distretto di Bussolengo
* UT-Unified State Labs: Public Health Utah DOH
* UW Virology Lab
* Unilabs Laboratory Medicine
* Unilabs Skovde
* Union Hospital of Tongji Medical College, Huazhong University of Science and Technology
* Universidade Federal do Rio de Janeiro
* Universidade Federal do Rio de Janeiro - UFRJ
* University Hospital Basel, Clinical Virology
* University Hospital of Northern Norway, Department for Microbiology and Infectious Disease Control
* University Hospitals of Geneva Laboratory of Virology
* University of Wisconsin - Madison AIDS Vaccine Research Laboratories
* University of Wisconsin - Madison: Influenza Research Institute
* University of Wisconsin-Madison AIDS Vaccine Research Laboratories
* University of Wisconsin-Madison AIDS Vaccine Research Laboratory
* University of Wisconsin-Madison, AIDS Vaccine Research Laboratories
* Unknown
* Utah Public Health Laboratory
* VA DCLS
* VA-Division of Consolidated Laboratory Services
* Vaccine Research, Development and Application Center, Erciyes University
* Valley Medical Center
* Vestfold Hospital, Tonsberg  Department of Microbiology
* Victorian Infectious Diseases Reference Laboratory (VIDRL)
* Viral Respiratory Lab, National Institute for Biomedical Research (INRB)
* Virginia Division of Consolidated Laboratories
* Virginia Division of Consolidated Laboratory Services
* ViroGenetics - BSL3 Laboratory of Virology; Human Genome Variation Research Group & Genomics Centre MCB; Bioinformatics Research Group  Department of Virology
* ViroGenetics - BSL3 Laboratory of Virology; Human Genome Variation Research Group & Genomics Centre MCB; Bioinformatics Research Group; Wojewodzka Stacja Sanitarno-Epidemiologiczna w Krakowie
* Virological Research Group, Szentagothai Research Centre
* Virological Research Group, Szentagothai Research Centre, University of Pecs
* Virology Department, Royal Infirmary of Edinburgh, NHS Lothian
* Virology Department, Royal Infirmary of Edinburgh, NHS Lothian / School of Biological Sciences, University of Edinburgh / Institute of Genetics and Molecular Medicine, University of Edinburgh
* Virology Department, Sheffield Teaching Hospitals NHS Foundation Trust
* Virology Laboratory, Department of Biomedical Sciences and Public Health, University Politecnica delle Marche
* Virology Unit, Institut Pasteur du Cambodge.
* Virology laboratory Ministry of Health Kuwait sequenced at Dasman Diabetes Institute
* WA State Department of Health
* WHO National Influenza Centre Russian Federation
* Wadsworth Center, New York State Department of Health
* Wadsworth Center, New York State Department.of Health
* Wales Specialist Virology Centre
* Washington State Department of Health
* Washington State Public Health Lab
* Weifang Center for Disease Control and Prevention
* Wellington Hospital
* West of Scotland Specialist Virology Centre, NHSGGC
* West of Scotland Specialist Virology Centre, NHSGGC / MRC-University of Glasgow Centre for Virus Research
* Wisconsin Department of Health Services
* Wuhan Fourth Hospital
* Wuhan Institute of Virology, Chinese Academy of Sciences
* Wuhan Jinyintan Hospital
* Wuhan Lung Hospital
* Wyoming Public Health Laboratory
* Yale COVID-19 Biorepository
* Yale Clinical Virology Laboratory
* Yongchuan District Center for Disease Control and Prevention
* Zhejiang Provincial Center for Disease Control and Prevention
* Zhongxian Center for Disease Control and Prevention
* deCODE genetics
```
