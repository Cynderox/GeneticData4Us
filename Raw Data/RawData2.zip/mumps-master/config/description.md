This work is made possible by the open sharing of genetic data by research groups from all over the world. We gratefully acknowledge their contributions.

Special thanks to Duah Alkam, Piroon Jenjaroenpun, Thidathip Wongsurawat, Zulema Udaondo, Preecha Patumcharoenpol, Michael Robeson, Dirk Haselow, William Mason, Intawat Nookaew, David Ussery, Se-Ran Jun, Jennifer Gardy, Shirlee Wohl, Jeff Joy, Patrick Stapleton, Nathan Yozwiak, Hayden Metsky, Agatha Jassem, Kelsey Florek, Gytis Dudas and Pardis Sabeti for data sharing, comments and suggestions.
