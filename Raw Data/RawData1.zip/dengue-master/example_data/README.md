FASTA fields follow:

1. `strain`
2. `virus`
3. `accession`
4. `collection_date`
5. `region`
6. `country`
7. `division`
8. `location`
9. `source`
10. `locus`
11. `authors`
12. `url`
13. `title`
14. `journal`
15. `puburl`
