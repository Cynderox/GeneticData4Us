This phylogeny shows a tree of full-length Human Coronavirus HKU1 sequences from ViPR.
