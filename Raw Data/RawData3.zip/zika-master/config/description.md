This work is made possible by the open sharing of genetic data by research groups from all over the world. We gratefully acknowledge their contributions.

Special thanks to Nick Loman, Nathan Grubaugh, Kristof Theys, Nuno Faria, Kristian Andersen, Andrew Rambaut and Karl Erlandson for data sharing, comments and suggestions.
